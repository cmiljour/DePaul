package view.interfaces;

public interface IShapeListReDrawObserver {
    void draw();
}
