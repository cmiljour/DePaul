package view.interfaces;

public interface ICommand {
    void run();
}
