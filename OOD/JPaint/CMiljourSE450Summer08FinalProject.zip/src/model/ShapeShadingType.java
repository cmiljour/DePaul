package model;

public enum ShapeShadingType {
    FILLED_IN,
    OUTLINE,
    OUTLINE_AND_FILLED_IN
}
